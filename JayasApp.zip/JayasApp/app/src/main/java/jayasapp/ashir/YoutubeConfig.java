package jayasapp.ashir;

/**
 * Created by ashir on 23-07-2018.
 */

public class YoutubeConfig {
    public YoutubeConfig(){}
    private  static  final  String API_KEY= "AIzaSyCUUOKfii-AQMHyeAJalskLDiu0OWxpkr8";
    public static  String getApiKey() {
        return API_KEY;
    }
    }

