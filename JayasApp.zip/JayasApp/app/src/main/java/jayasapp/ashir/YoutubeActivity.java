package jayasapp.ashir;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.google.android.youtube.player.YouTubeBaseActivity;
import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.YouTubePlayer;
import com.google.android.youtube.player.YouTubePlayerView;

import java.util.ArrayList;
import java.util.HashMap;

public class YoutubeActivity extends YouTubeBaseActivity {
    YouTubePlayerView mYoutubePlayerView;
    Button PlayBtn;
    YouTubePlayer.OnInitializedListener mOninitializeListener;
    public static TextView data;
    static ListView listVideo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_youtube);
       data  = (TextView)findViewById(R.id.Textfetch);
        PlayBtn = (Button)findViewById(R.id.ytplaybtn);
    mYoutubePlayerView = (YouTubePlayerView)findViewById(R.id.youtubePlay);
    listVideo = (ListView)findViewById(R.id.list) ;

    mOninitializeListener = new YouTubePlayer.OnInitializedListener() {
        @Override
        public void onInitializationSuccess(YouTubePlayer.Provider provider, YouTubePlayer youTubePlayer, boolean b) {
        youTubePlayer.loadPlaylist("LLax9CJCQ6aY0bntP3mcIWKQ");
        }

        @Override
        public void onInitializationFailure(YouTubePlayer.Provider provider, YouTubeInitializationResult youTubeInitializationResult) {

        }

    };



    PlayBtn.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
                JsonFetch process = new JsonFetch();
                process.execute();
            mYoutubePlayerView.initialize(YoutubeConfig.getApiKey(),mOninitializeListener);
        }
    });
    }


//    ListAdapter adapter = new SimpleAdapter(
//            YoutubeActivity.this, ListPlay,
//            R.layout.activity_video_list, new String[]{"Title"}, new int[]{R.id.Title});
//
//
//}


}

