package jayasapp.ashir;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class VideoList {
    static String  title;
    static  String  videoId;
    static String thumbnail;

}
